import logo from './logo.svg';
import './App.css';

function App() {
    const names = ["Ram", "Shyam", "John", "Mac"];
    const updateNames = names.map((name, index) => {
      return <li key={index}>{name}</li>;
    });

    return (
      <ul>
        {updateNames}
      </ul>
    );
}

// Component to be extracted
function MenuItems(props) {
  const item = props.item;
  // return <li key={item.toString()}>{item}</li>
  return <li>{item}</li>
}

function Navigation(props) {
  const names = ["Ram", "Shyam", "John", "Mac"];
  // const list = props.names;
  const updatedNames = names.map((item) => {
    return <MenuItems key={item.toString()} item={item}/>;
  })
  return <ul>{updatedNames}</ul>
}

export default Navigation;
