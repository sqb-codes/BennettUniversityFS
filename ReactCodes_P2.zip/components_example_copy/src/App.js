import logo from './logo.svg';
import './App.css';
import React from 'react';
import ReactDOM from 'react-dom/client';

function App() {
  const element = (
    <div>
      <h1>React Component Example...</h1>
      <h2>Current Time : {new Date().toLocaleTimeString()}</h2>
    </div>
  )
  const root = ReactDOM.createRoot(document.getElementById('root'));
  root.render(element);
}

setInterval(App, 1000);

export default App;
