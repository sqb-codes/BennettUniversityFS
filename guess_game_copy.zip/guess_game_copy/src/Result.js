import React from 'react';

const Result = ({num, cpu}) => {
    let result;
    if(num > cpu) {
        result = "You have guessed higher number";
    }
    else if(num < cpu) {
        result = "You have guessed smaller number";
    }
    else if(num == cpu) {
        result = "Congrats...You won the game...";
    }
    else {
        result = "Enter valid number..."
    }
    return <h4>Result : {result}</h4>
}

export default Result;