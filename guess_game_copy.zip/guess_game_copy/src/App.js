import logo from './logo.svg';
import './App.css';
import React, {Component} from 'react';
import Result from './Result';

class App extends Component {

  static defaultProps = {
    cpu : Math.floor(Math.random() * 50) + 1
  }

  constructor(props) {
    super(props)
    this.state = {guess : ''}
    this.guessNum =  this.guessNum.bind(this);
  }

  guessNum(event) {
    this.setState({
      [event.target.name] : event.target.value
    });
  }

  render() {
    return (
      <div>
        <label>Enter the number</label>
        <input type='text' placeholder='Enter the number' name='guess' value={this.state.guess} 
        onChange={this.guessNum}/>

        <Result num={this.state.guess} cpu={this.props.cpu}/>
      </div>
    )
  }
}

export default App;
