import logo from './logo.svg';
import './App.css';

// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>
//     </div>
//   );
// }

// function App() {
//   let username = "Ram";
//   const element = (
//     <h2>Hello {username}... This is React Example</h2>
//   );
//   return element;
// }

// function App() {
//   let username = "Ramesh";
//   const element = (
//     <h2>{username == "Ram" ? "Hello Ram" : "Invalid User..."}</h2>
//   );
//   return element;
// }

function App() {
  let username = "Ram";
  const element = (
    <div>
      <h1 className="title">Hello Using React...</h1>
      <h2>{username === "Ram" ? "Hello Ram" : "Invalid User..."}</h2>
      <img src={logo} className="App-logo" alt="logo" />
    </div>
  );
  return element;
}

export default App;
