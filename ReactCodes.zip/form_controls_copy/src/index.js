import React from 'react';
// import ReactDOM from 'react-dom';
import ReactDOM from 'react-dom/client';

class App extends React.Component {

  state = {boxValue : ""};

  // onInputChange(event) {
  //   // console.log(event.target.value);
  //   this.setState({inputValue : event.target.value});
  // }

  render() {
    return (
      <div className='form'>
        <h1>React Form Control Example...</h1>
        <form>
          <label>Enter your name</label>
          {/* <input type="text" placeholder='Enter your name' value={this.state.inputValue} onChange={this.onInputChange}/> */}

          <input type="text" placeholder='Enter your name' value={this.state.boxValue} onChange={(event) => this.setState({
            boxValue : event.target.value,
          })}/>

        </form>
        <h2>Welcome : {this.state.boxValue}</h2>
      </div>
    );
  }
}


// ReactDOM.createRoot(<App/>, document.getElementById('root'));

const root = ReactDOM.createRoot(document.querySelector('#root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);